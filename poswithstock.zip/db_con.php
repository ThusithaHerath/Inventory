<?php
$con=mysql_connect("localhost","texdcqat_stock_manager","Admin@2021");
mysql_select_db("texdcqat_stockmanagement_db",$con) or die(mysql_error($con));
error_reporting(E_ALL ^ E_NOTICE);
?>