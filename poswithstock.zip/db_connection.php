<?php

$servername = "localhost";
$username = "texdcqat_stock_manager";
$password = "Admin@2021";
$dbname = "texdcqat_stockmanagement_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 


?>