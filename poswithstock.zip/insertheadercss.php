  <!-- simplebar CSS-->
  <link href="./assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
  <!-- Bootstrap core CSS-->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <!--Data Tables -->
  <link href="./assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <link href="./assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <!-- animate CSS-->
  <link href="./assets/css/animate.css" rel="stylesheet" type="text/css" />
  <!-- Icons CSS-->
  <link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
  <!-- Sidebar CSS-->
  <link href="./assets/css/sidebar-menu.css" rel="stylesheet" />
  <!-- Custom Style-->
  <link href="./assets/css/app-style2.css" rel="stylesheet" />