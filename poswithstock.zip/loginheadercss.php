  <!-- Bootstrap core CSS-->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <!-- animate CSS-->
  <link href="./assets/css/animate.css" rel="stylesheet" type="text/css" />
  <!-- Icons CSS-->
  <link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
  <!-- Custom Style-->
  <link href="./assets/css/app-style2.css" rel="stylesheet" />