<!-- Bootstrap core JavaScript-->
  <script src="./assets/js/jquery.min.js"></script>
  <script src="./assets/js/popper.min.js"></script>
  <script src="./assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="./assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="./assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="./assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="./assets/js/app-script.js"></script>
  
  <!-- Vector map JavaScript -->
  <script src="./assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
  <script src="./assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- Chart js -->
  <script src="./assets/plugins/Chart.js/Chart.min.js"></script>
  <!-- Index js -->
  <script src="./assets/js/index.js"></script>
  