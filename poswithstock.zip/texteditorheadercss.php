<script type="text/javascript" src="plugin/tinymce/tinymce.min.js"></script>
  
<script type="text/javascript" src="plugin/tinymce/init-tinymce.js"></script>